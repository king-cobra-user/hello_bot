<h3>☣️ The Most Powerfull Userbot ☣️</h3>

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/f7c51539e67b483bb8d7749acca51d3a)](https://app.codacy.com/gh/HellBoy-OP/HellBot?utm_source=github.com&utm_medium=referral&utm_content=HellBoy-OP/HellBot&utm_campaign=Badge_Grade_Settings)
[![Python 3.6](https://img.shields.io/badge/Python-3.6%20or%20newer-blue.svg)](https://www.python.org/downloads/release/python-360/)

![GitHub repo size](https://img.shields.io/github/repo-size/HellBoy-OP/Hellbot)
[![Contact Me](https://img.shields.io/badge/Telegram-Contact%20Me-informational)](https://t.me/kraken_the_badass)

<h1 align="center">⚡ †hê Hêllẞø† ⚡</h1>

<h4 align="center">Legendary AF HellBot</h4>

<h5>This is a userbot made for telegram. I made this userbot with help of all other userbots available in telegram. All credits goes to its Respective Owners.</h5>

This is the one and only official HellBot Userbot made by #Team_HellBoy.

Don't forget to star this repo if you liked it.

Enjoy Your Bot!!💝

[![HellBot logo](https://telegra.ph/file/2165457cc7e428ff64919.jpg)](https://t.me/hellbot_official)

### The owner would not be responsible for any kind of bans due to the bot...

# FORK AT YOUR OWN RISK

<details>

  <summary> Credits 🏅 </summary>

• [JaaduBot](https://github.com/Amberyt/JaaduBot)

• [CatUserbot](https://github.com/sandy1709/catuserbot)

• [Uniborg](https://github.com/spechide/uniborg)

</details>

<details>

  <summary> Official Supports ✅ </summary>

```

Get help regarding setting up 

your Hêllẞø† in our official 

support Group and get updates

notifications in Update Channel.

```

<a href="https://t.me/HellBot_Official"><img src="https://img.shields.io/badge/Join-Support%20Channel-red.svg?style=for-the-badge&logo=Telegram"></a>

<a href="https://t.me/HellBot_Official_Chat"><img src="https://img.shields.io/badge/Join-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>

</details>

<details>

  <summary> Video Tutorial 📺 </summary>

```

Official YouTube Channel Of Hêllẞø†.

Click on the link below to get tutorial on 

How To Deploy Hêllẞø†.

```

<a href="https://youtu.be/M2FQJq_sHp4"><img src="https://img.shields.io/badge/How%20To%20Deploy-blue.svg?logo=Youtube"></a>

<a href="https://youtu.be/M2FQJq_sHp4"><img src="https://img.shields.io/youtube/views/M2FQJq_sHp4?style=social"></a>

</details>

<h2 align="center">⚙️ Set-Up ⚙️</h2>

<h3 align="center">✨ The Easy Way ✨</h3>

<h4>⚜️ DEPLOY TO HEROKU ⚜️</h4>

<a href="https://dashboard.heroku.com/new?button-url=https%3A%2F%2Fgithub.com%2FHellBoy-OP%2FHellBot&template=https%3A%2F%2Fgithub.com%2FHellBoy-OP%2FHellBot" rel="nofollow" style="background-color: initial; box-sizing: border-box; color: #0366d6; text-decoration-line: none;"><img alt="Deploy" data-canonical-src="https://www.herokucdn.com/deploy/button.svg" src="https://camo.githubusercontent.com/83b0e95b38892b49184e07ad572c94c8038323fb/68747470733a2f2f7777772e6865726f6b7563646e2e636f6d2f6465706c6f792f627574746f6e2e737667" style="border-style: none; box-sizing: initial; max-width: 100%;" /></a></div>

</a>

<h3 align="center">⚔️ The Normal Way ⚔️</h3>

<h4 align="center">To host Héllẞø† locally or on any other VPS, Go to</h4>

<h2 align="center"> <a href="https://github.com/thevaders/vader">⚡ VΛDΣЯ REPO ⚡</a></h2>

## Mandatory Vars

- Only two of the environment variables are mandatory.

- This is because of `telethon.errors.rpc_error_list.ApiIdPublishedFloodError`

    - `APP_ID`:   You can get this value from https://my.telegram.org

    - `API_HASH`:   You can get this value from https://my.telegram.org

- The userbot will not work without setting the mandatory vars.

<details>

  <summary> • LICENSE • </summary>

![](https://www.gnu.org/graphics/gplv3-or-later.png)

Copyright (C) 2021 HellBoy-OP

Poject [HellBot](https://github.com/HellBoy-OP/HellBot) is free software: you can redistribute it and/or modify

it under the terms of the GNU General Public License as published by

the Free Software Foundation, either version 3 of the License, or

(at your option) any later version.

This program is distributed in the hope that it will be useful,

but WITHOUT ANY WARRANTY; without even the implied warranty of

MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

GNU General Public License for more details.

You should have received a copy of the GNU General Public License

along with this program. If not, see <https://www.gnu.org/licenses/>.

</details>
